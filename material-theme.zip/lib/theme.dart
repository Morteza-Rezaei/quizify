import "package:flutter/material.dart";

class MaterialTheme {
  final TextTheme textTheme;

  const MaterialTheme(this.textTheme);

  static MaterialScheme lightScheme() {
    return const MaterialScheme(
      brightness: Brightness.light,
      primary: Color(4281819534),
      surfaceTint: Color(4281819534),
      onPrimary: Color(4294967295),
      primaryContainer: Color(4292011263),
      onPrimaryContainer: Color(4278197303),
      secondary: Color(4282343312),
      onSecondary: Color(4294967295),
      secondaryContainer: Color(4292207615),
      onSecondaryContainer: Color(4278197052),
      tertiary: Color(4283914642),
      onTertiary: Color(4294967295),
      tertiaryContainer: Color(4292993279),
      onTertiaryContainer: Color(4279440459),
      error: Color(4287646279),
      onError: Color(4294967295),
      errorContainer: Color(4294957783),
      onErrorContainer: Color(4282058762),
      background: Color(4294507007),
      onBackground: Color(4279835680),
      surface: Color(4294376190),
      onSurface: Color(4279704607),
      surfaceVariant: Color(4292666345),
      onSurfaceVariant: Color(4282468429),
      outline: Color(4285626493),
      outlineVariant: Color(4290824141),
      shadow: Color(4278190080),
      scrim: Color(4278190080),
      inverseSurface: Color(4281086260),
      inverseOnSurface: Color(4293784053),
      inversePrimary: Color(4288793085),
      primaryFixed: Color(4292011263),
      onPrimaryFixed: Color(4278197303),
      primaryFixedDim: Color(4288793085),
      onPrimaryFixedVariant: Color(4279978357),
      secondaryFixed: Color(4292207615),
      onSecondaryFixed: Color(4278197052),
      secondaryFixedDim: Color(4289251583),
      onSecondaryFixedVariant: Color(4280633207),
      tertiaryFixed: Color(4292993279),
      onTertiaryFixed: Color(4279440459),
      tertiaryFixedDim: Color(4290822655),
      onTertiaryFixedVariant: Color(4282335608),
      surfaceDim: Color(4292270814),
      surfaceBright: Color(4294376190),
      surfaceContainerLowest: Color(4294967295),
      surfaceContainerLow: Color(4293981432),
      surfaceContainer: Color(4293586674),
      surfaceContainerHigh: Color(4293257709),
      surfaceContainerHighest: Color(4292862951),
    );
  }

  ThemeData light() {
    return theme(lightScheme().toColorScheme());
  }

  static MaterialScheme lightMediumContrastScheme() {
    return const MaterialScheme(
      brightness: Brightness.light,
      primary: Color(4279584113),
      surfaceTint: Color(4281819534),
      onPrimary: Color(4294967295),
      primaryContainer: Color(4283398054),
      onPrimaryContainer: Color(4294967295),
      secondary: Color(4280304499),
      onSecondary: Color(4294967295),
      secondaryContainer: Color(4283856296),
      onSecondaryContainer: Color(4294967295),
      tertiary: Color(4282072436),
      onTertiary: Color(4294967295),
      tertiaryContainer: Color(4285362090),
      onTertiaryContainer: Color(4294967295),
      error: Color(4285411117),
      onError: Color(4294967295),
      errorContainer: Color(4289355612),
      onErrorContainer: Color(4294967295),
      background: Color(4294507007),
      onBackground: Color(4279835680),
      surface: Color(4294376190),
      onSurface: Color(4279704607),
      surfaceVariant: Color(4292666345),
      onSurfaceVariant: Color(4282205257),
      outline: Color(4284047461),
      outlineVariant: Color(4285824129),
      shadow: Color(4278190080),
      scrim: Color(4278190080),
      inverseSurface: Color(4281086260),
      inverseOnSurface: Color(4293784053),
      inversePrimary: Color(4288793085),
      primaryFixed: Color(4283398054),
      onPrimaryFixed: Color(4294967295),
      primaryFixedDim: Color(4281622156),
      onPrimaryFixedVariant: Color(4294967295),
      secondaryFixed: Color(4283856296),
      onSecondaryFixed: Color(4294967295),
      secondaryFixedDim: Color(4282146190),
      onSecondaryFixedVariant: Color(4294967295),
      tertiaryFixed: Color(4285362090),
      onTertiaryFixed: Color(4294967295),
      tertiaryFixedDim: Color(4283783055),
      onTertiaryFixedVariant: Color(4294967295),
      surfaceDim: Color(4292270814),
      surfaceBright: Color(4294376190),
      surfaceContainerLowest: Color(4294967295),
      surfaceContainerLow: Color(4293981432),
      surfaceContainer: Color(4293586674),
      surfaceContainerHigh: Color(4293257709),
      surfaceContainerHighest: Color(4292862951),
    );
  }

  ThemeData lightMediumContrast() {
    return theme(lightMediumContrastScheme().toColorScheme());
  }

  static MaterialScheme lightHighContrastScheme() {
    return const MaterialScheme(
      brightness: Brightness.light,
      primary: Color(4278199106),
      surfaceTint: Color(4281819534),
      onPrimary: Color(4294967295),
      primaryContainer: Color(4279584113),
      onPrimaryContainer: Color(4294967295),
      secondary: Color(4278198856),
      onSecondary: Color(4294967295),
      secondaryContainer: Color(4280304499),
      onSecondaryContainer: Color(4294967295),
      tertiary: Color(4279901009),
      onTertiary: Color(4294967295),
      tertiaryContainer: Color(4282072436),
      onTertiaryContainer: Color(4294967295),
      error: Color(4282650384),
      onError: Color(4294967295),
      errorContainer: Color(4285411117),
      onErrorContainer: Color(4294967295),
      background: Color(4294507007),
      onBackground: Color(4279835680),
      surface: Color(4294376190),
      onSurface: Color(4278190080),
      surfaceVariant: Color(4292666345),
      onSurfaceVariant: Color(4280165673),
      outline: Color(4282205257),
      outlineVariant: Color(4282205257),
      shadow: Color(4278190080),
      scrim: Color(4278190080),
      inverseSurface: Color(4281086260),
      inverseOnSurface: Color(4294967295),
      inversePrimary: Color(4293062143),
      primaryFixed: Color(4279584113),
      onPrimaryFixed: Color(4294967295),
      primaryFixedDim: Color(4278201939),
      onPrimaryFixedVariant: Color(4294967295),
      secondaryFixed: Color(4280304499),
      onSecondaryFixed: Color(4294967295),
      secondaryFixedDim: Color(4278201435),
      onSecondaryFixedVariant: Color(4294967295),
      tertiaryFixed: Color(4282072436),
      onTertiaryFixed: Color(4294967295),
      tertiaryFixedDim: Color(4280624732),
      onTertiaryFixedVariant: Color(4294967295),
      surfaceDim: Color(4292270814),
      surfaceBright: Color(4294376190),
      surfaceContainerLowest: Color(4294967295),
      surfaceContainerLow: Color(4293981432),
      surfaceContainer: Color(4293586674),
      surfaceContainerHigh: Color(4293257709),
      surfaceContainerHighest: Color(4292862951),
    );
  }

  ThemeData lightHighContrast() {
    return theme(lightHighContrastScheme().toColorScheme());
  }

  static MaterialScheme darkScheme() {
    return const MaterialScheme(
      brightness: Brightness.dark,
      primary: Color(4288793085),
      surfaceTint: Color(4288793085),
      onPrimary: Color(4278202969),
      primaryContainer: Color(4279978357),
      onPrimaryContainer: Color(4292011263),
      secondary: Color(4289251583),
      onSecondary: Color(4278530143),
      secondaryContainer: Color(4280633207),
      onSecondaryContainer: Color(4292207615),
      tertiary: Color(4290822655),
      onTertiary: Color(4280887904),
      tertiaryContainer: Color(4282335608),
      onTertiaryContainer: Color(4292993279),
      error: Color(4294947759),
      onError: Color(4283899164),
      errorContainer: Color(4285739825),
      onErrorContainer: Color(4294957783),
      background: Color(4279309336),
      onBackground: Color(4292993768),
      surface: Color(4279178263),
      onSurface: Color(4292862951),
      surfaceVariant: Color(4282468429),
      onSurfaceVariant: Color(4290824141),
      outline: Color(4287271575),
      outlineVariant: Color(4282468429),
      shadow: Color(4278190080),
      scrim: Color(4278190080),
      inverseSurface: Color(4292862951),
      inverseOnSurface: Color(4281086260),
      inversePrimary: Color(4281819534),
      primaryFixed: Color(4292011263),
      onPrimaryFixed: Color(4278197303),
      primaryFixedDim: Color(4288793085),
      onPrimaryFixedVariant: Color(4279978357),
      secondaryFixed: Color(4292207615),
      onSecondaryFixed: Color(4278197052),
      secondaryFixedDim: Color(4289251583),
      onSecondaryFixedVariant: Color(4280633207),
      tertiaryFixed: Color(4292993279),
      onTertiaryFixed: Color(4279440459),
      tertiaryFixedDim: Color(4290822655),
      onTertiaryFixedVariant: Color(4282335608),
      surfaceDim: Color(4279178263),
      surfaceBright: Color(4281678397),
      surfaceContainerLowest: Color(4278849298),
      surfaceContainerLow: Color(4279704607),
      surfaceContainer: Color(4279967779),
      surfaceContainerHigh: Color(4280691502),
      surfaceContainerHighest: Color(4281414969),
    );
  }

  ThemeData dark() {
    return theme(darkScheme().toColorScheme());
  }

  static MaterialScheme darkMediumContrastScheme() {
    return const MaterialScheme(
      brightness: Brightness.dark,
      primary: Color(4289253119),
      surfaceTint: Color(4288793085),
      onPrimary: Color(4278196014),
      primaryContainer: Color(4285240260),
      onPrimaryContainer: Color(4278190080),
      secondary: Color(4289711359),
      onSecondary: Color(4278195763),
      secondaryContainer: Color(4285698758),
      onSecondaryContainer: Color(4278190080),
      tertiary: Color(4291151615),
      onTertiary: Color(4279045445),
      tertiaryContainer: Color(4287269832),
      onTertiaryContainer: Color(4278190080),
      error: Color(4294949301),
      onError: Color(4281533446),
      errorContainer: Color(4291525494),
      onErrorContainer: Color(4278190080),
      background: Color(4279309336),
      onBackground: Color(4292993768),
      surface: Color(4279178263),
      onSurface: Color(4294441983),
      surfaceVariant: Color(4282468429),
      onSurfaceVariant: Color(4291153105),
      outline: Color(4288521385),
      outlineVariant: Color(4286416009),
      shadow: Color(4278190080),
      scrim: Color(4278190080),
      inverseSurface: Color(4292862951),
      inverseOnSurface: Color(4280691502),
      inversePrimary: Color(4280109686),
      primaryFixed: Color(4292011263),
      onPrimaryFixed: Color(4278194725),
      primaryFixedDim: Color(4288793085),
      onPrimaryFixedVariant: Color(4278204515),
      secondaryFixed: Color(4292207615),
      onSecondaryFixed: Color(4278194474),
      secondaryFixedDim: Color(4289251583),
      onSecondaryFixedVariant: Color(4279187045),
      tertiaryFixed: Color(4292993279),
      onTertiaryFixed: Color(4278650433),
      tertiaryFixedDim: Color(4290822655),
      onTertiaryFixedVariant: Color(4281217126),
      surfaceDim: Color(4279178263),
      surfaceBright: Color(4281678397),
      surfaceContainerLowest: Color(4278849298),
      surfaceContainerLow: Color(4279704607),
      surfaceContainer: Color(4279967779),
      surfaceContainerHigh: Color(4280691502),
      surfaceContainerHighest: Color(4281414969),
    );
  }

  ThemeData darkMediumContrast() {
    return theme(darkMediumContrastScheme().toColorScheme());
  }

  static MaterialScheme darkHighContrastScheme() {
    return const MaterialScheme(
      brightness: Brightness.dark,
      primary: Color(4294638335),
      surfaceTint: Color(4288793085),
      onPrimary: Color(4278190080),
      primaryContainer: Color(4289253119),
      onPrimaryContainer: Color(4278190080),
      secondary: Color(4294703871),
      onSecondary: Color(4278190080),
      secondaryContainer: Color(4289711359),
      onSecondaryContainer: Color(4278190080),
      tertiary: Color(4294834687),
      onTertiary: Color(4278190080),
      tertiaryContainer: Color(4291151615),
      onTertiaryContainer: Color(4278190080),
      error: Color(4294965753),
      onError: Color(4278190080),
      errorContainer: Color(4294949301),
      onErrorContainer: Color(4278190080),
      background: Color(4279309336),
      onBackground: Color(4292993768),
      surface: Color(4279178263),
      onSurface: Color(4294967295),
      surfaceVariant: Color(4282468429),
      onSurfaceVariant: Color(4294507519),
      outline: Color(4291153105),
      outlineVariant: Color(4291153105),
      shadow: Color(4278190080),
      scrim: Color(4278190080),
      inverseSurface: Color(4292862951),
      inverseOnSurface: Color(4278190080),
      inversePrimary: Color(4278201167),
      primaryFixed: Color(4292471039),
      onPrimaryFixed: Color(4278190080),
      primaryFixedDim: Color(4289253119),
      onPrimaryFixedVariant: Color(4278196014),
      secondaryFixed: Color(4292667391),
      onSecondaryFixed: Color(4278190080),
      secondaryFixedDim: Color(4289711359),
      onSecondaryFixedVariant: Color(4278195763),
      tertiaryFixed: Color(4293321983),
      onTertiaryFixed: Color(4278190080),
      tertiaryFixedDim: Color(4291151615),
      onTertiaryFixedVariant: Color(4279045445),
      surfaceDim: Color(4279178263),
      surfaceBright: Color(4281678397),
      surfaceContainerLowest: Color(4278849298),
      surfaceContainerLow: Color(4279704607),
      surfaceContainer: Color(4279967779),
      surfaceContainerHigh: Color(4280691502),
      surfaceContainerHighest: Color(4281414969),
    );
  }

  ThemeData darkHighContrast() {
    return theme(darkHighContrastScheme().toColorScheme());
  }


  ThemeData theme(ColorScheme colorScheme) => ThemeData(
     useMaterial3: true,
     brightness: colorScheme.brightness,
     colorScheme: colorScheme,
     textTheme: textTheme.apply(
       bodyColor: colorScheme.onSurface,
       displayColor: colorScheme.onSurface,
     ),
     scaffoldBackgroundColor: colorScheme.background,
     canvasColor: colorScheme.surface,
  );


  List<ExtendedColor> get extendedColors => [
  ];
}

class MaterialScheme {
  const MaterialScheme({
    required this.brightness,
    required this.primary, 
    required this.surfaceTint, 
    required this.onPrimary, 
    required this.primaryContainer, 
    required this.onPrimaryContainer, 
    required this.secondary, 
    required this.onSecondary, 
    required this.secondaryContainer, 
    required this.onSecondaryContainer, 
    required this.tertiary, 
    required this.onTertiary, 
    required this.tertiaryContainer, 
    required this.onTertiaryContainer, 
    required this.error, 
    required this.onError, 
    required this.errorContainer, 
    required this.onErrorContainer, 
    required this.background, 
    required this.onBackground, 
    required this.surface, 
    required this.onSurface, 
    required this.surfaceVariant, 
    required this.onSurfaceVariant, 
    required this.outline, 
    required this.outlineVariant, 
    required this.shadow, 
    required this.scrim, 
    required this.inverseSurface, 
    required this.inverseOnSurface, 
    required this.inversePrimary, 
    required this.primaryFixed, 
    required this.onPrimaryFixed, 
    required this.primaryFixedDim, 
    required this.onPrimaryFixedVariant, 
    required this.secondaryFixed, 
    required this.onSecondaryFixed, 
    required this.secondaryFixedDim, 
    required this.onSecondaryFixedVariant, 
    required this.tertiaryFixed, 
    required this.onTertiaryFixed, 
    required this.tertiaryFixedDim, 
    required this.onTertiaryFixedVariant, 
    required this.surfaceDim, 
    required this.surfaceBright, 
    required this.surfaceContainerLowest, 
    required this.surfaceContainerLow, 
    required this.surfaceContainer, 
    required this.surfaceContainerHigh, 
    required this.surfaceContainerHighest, 
  });

  final Brightness brightness;
  final Color primary;
  final Color surfaceTint;
  final Color onPrimary;
  final Color primaryContainer;
  final Color onPrimaryContainer;
  final Color secondary;
  final Color onSecondary;
  final Color secondaryContainer;
  final Color onSecondaryContainer;
  final Color tertiary;
  final Color onTertiary;
  final Color tertiaryContainer;
  final Color onTertiaryContainer;
  final Color error;
  final Color onError;
  final Color errorContainer;
  final Color onErrorContainer;
  final Color background;
  final Color onBackground;
  final Color surface;
  final Color onSurface;
  final Color surfaceVariant;
  final Color onSurfaceVariant;
  final Color outline;
  final Color outlineVariant;
  final Color shadow;
  final Color scrim;
  final Color inverseSurface;
  final Color inverseOnSurface;
  final Color inversePrimary;
  final Color primaryFixed;
  final Color onPrimaryFixed;
  final Color primaryFixedDim;
  final Color onPrimaryFixedVariant;
  final Color secondaryFixed;
  final Color onSecondaryFixed;
  final Color secondaryFixedDim;
  final Color onSecondaryFixedVariant;
  final Color tertiaryFixed;
  final Color onTertiaryFixed;
  final Color tertiaryFixedDim;
  final Color onTertiaryFixedVariant;
  final Color surfaceDim;
  final Color surfaceBright;
  final Color surfaceContainerLowest;
  final Color surfaceContainerLow;
  final Color surfaceContainer;
  final Color surfaceContainerHigh;
  final Color surfaceContainerHighest;
}

extension MaterialSchemeUtils on MaterialScheme {
  ColorScheme toColorScheme() {
    return ColorScheme(
      brightness: brightness,
      primary: primary,
      onPrimary: onPrimary,
      primaryContainer: primaryContainer,
      onPrimaryContainer: onPrimaryContainer,
      secondary: secondary,
      onSecondary: onSecondary,
      secondaryContainer: secondaryContainer,
      onSecondaryContainer: onSecondaryContainer,
      tertiary: tertiary,
      onTertiary: onTertiary,
      tertiaryContainer: tertiaryContainer,
      onTertiaryContainer: onTertiaryContainer,
      error: error,
      onError: onError,
      errorContainer: errorContainer,
      onErrorContainer: onErrorContainer,
      background: background,
      onBackground: onBackground,
      surface: surface,
      onSurface: onSurface,
      surfaceVariant: surfaceVariant,
      onSurfaceVariant: onSurfaceVariant,
      outline: outline,
      outlineVariant: outlineVariant,
      shadow: shadow,
      scrim: scrim,
      inverseSurface: inverseSurface,
      onInverseSurface: inverseOnSurface,
      inversePrimary: inversePrimary,
    );
  }
}

class ExtendedColor {
  final Color seed, value;
  final ColorFamily light;
  final ColorFamily lightHighContrast;
  final ColorFamily lightMediumContrast;
  final ColorFamily dark;
  final ColorFamily darkHighContrast;
  final ColorFamily darkMediumContrast;

  const ExtendedColor({
    required this.seed,
    required this.value,
    required this.light,
    required this.lightHighContrast,
    required this.lightMediumContrast,
    required this.dark,
    required this.darkHighContrast,
    required this.darkMediumContrast,
  });
}

class ColorFamily {
  const ColorFamily({
    required this.color,
    required this.onColor,
    required this.colorContainer,
    required this.onColorContainer,
  });

  final Color color;
  final Color onColor;
  final Color colorContainer;
  final Color onColorContainer;
}
